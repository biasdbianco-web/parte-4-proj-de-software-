# Correspondência UML ↔ Código Java

Pacote base: `br.com.minharefeicao` (código em `src/br/com/minharefeicao/`).

## 1. Estímulos do ator → fronteira → controlador

| Tela do protótipo | Método da fronteira (`TelaAssinatura`) | Estímulo no controlador (`AssinaturaController`) |
|---|---|---|
| Tela 1 – Informar celular | `telaInformarCelular()` | `informarCelular(celular)` |
| Tela 2 – Confirmar código SMS (FA1) | `telaConfirmarCodigo()` | `informarCodigo(codigo)` |
| Tela 3 – Escolher plano | `telaEscolherPlano()` | `listarPlanos()`, `selecionarPlano(idPlano)` |
| Tela 4 – Preferências | `telaPreferencias()` | `informarPreferencias(preferencias)` |
| Tela 5 – Pratos principais (FA2) | `telaPratosPrincipais()` | `listarPratos(PRINCIPAL)`, `selecionarPratos(ids)` |
| Tela 6 – Acompanhamentos e sobremesas | `telaAcompanhamentosESobremesas()` | `selecionarAcompanhamentos(ids)`, `selecionarSobremesas(ids)` |
| Tela 7 – Resumo do pedido | `telaResumoPedido()` | `consultarResumoPedido()` |
| Tela 8 – Endereço | `telaEndereco()` | `informarEndereco(endereco)` |
| Telas 9 e 10 – Pagamento e autorização (FA3) | `telaPagamento(valor)` | `informarDadosPagamento(cartao)`, `cancelarAssinatura()` |
| Tela 11 – Assinatura ativa | `telaConfirmacao()` | `obterResumoConfirmacao()` |

## 2. Mensagens do diagrama de sequência → classe e método

| Mensagem | Classe Java | Método |
|---|---|---|
| `buscarOuCriar(celular)` | `catalogo.CatalogoAssinantes` | `buscarOuCriar(String)` |
| `enviarCodigo`, `validarCodigo`, `invalidarCodigo` | `servico.ServicoSMS` | `enviarCodigo`, `validarCodigo`, `invalidarCodigo` |
| `listarDisponiveis()`, `buscarPorId(id)` | `catalogo.CatalogoPlanos` | idem |
| `definirPreferencias(prefs)` | `entidade.Assinante` | `definirPreferencias(List<String>)` |
| `listarPratos(categoria, preferencias)` | `catalogo.Cardapio` | idem |
| `adicionarRefeicoes(pratos)` | `entidade.Assinatura` | `adicionarRefeicoes(List<Prato>)` — lança `QuantidadeExcedidaException` (FA2) |
| `adicionarItem(prato, quantidade)`, `getComposicao()`, `getQuantidadeTotal()` | `entidade.Pedido` | idem |
| `definirEndereco`, `alterarStatus`, `calcularValorTotal`, `definirProtocolo`, `encerrarSemAtivacao`, `getResumoConfirmacao` | `entidade.Assinatura` | idem |
| `autorizar(cartao, valor)` | `servico.OperadoraCartaoCredito` | `autorizar(CartaoCredito, double)` |
| `registrar()` | `entidade.Pagamento` | `registrar()` |
| `ativar()` | `entidade.Assinatura` | `ativar(Pagamento)` |
| `gerar()` | `servico.GeradorProtocolo` | `gerar()` |

## 3. Relacionamentos do diagrama de classes → código

| Relacionamento UML | Implementação |
|---|---|
| Composição `Assinatura ◆— Pedido` | campo `private final Pedido pedido = new Pedido();` em `Assinatura` (o pedido nasce e morre com a assinatura) |
| Composição `Pedido ◆— ItemPedido` | lista `itens` criada e mantida dentro de `Pedido` |
| Composição `Assinante ◆— PreferenciaAlimentar` | lista `preferencias` dentro de `Assinante` |
| Composição `Assinatura ◆— Pagamento` | campo `pagamento`, atribuído em `ativar(pagamento)` |
| Agregação `Assinatura ◇— EnderecoEntrega` | campo `endereco` recebido de fora em `definirEndereco` |
| Agregação `Cardapio ◇— Prato` | lista `pratos` carregada de `data/pratos.csv` |
| Associação `Assinatura → PlanoAssinatura` | campo `plano` recebido no construtor |
| Classe associativa `ItemPedido` (Pedido × Prato) | `ItemPedido` guarda `prato` e `quantidade` |
| Dependência `AssinaturaController ⇢ serviços/catálogos` | campos `final` injetados no construtor (montados em `Main`) |

## 4. Ajustes em relação aos diagramas da fase de projeto

| Ajuste | Motivo |
|---|---|
| Incluída a fronteira `TelaAssinatura` | A implementação precisa de uma classe de interface; no diagrama o Assinante falava direto com o controlador. |
| `Assinatura.ativar(pagamento)` em vez de `ativar()` | A assinatura guarda o pagamento aprovado. A ordem continua a do diagrama: `autorizar` → `Pagamento.registrar` → `Assinatura.ativar`. |
| `Pedido.getQuantidadePorCategoria(categoria)` | A cota do plano conta só pratos principais; o diagrama tinha apenas `getQuantidadeTotal()`, que foi mantido. |
| Novo estado `EM_CRIACAO` em `StatusAssinatura` | Estado da assinatura antes do endereço (passo 20). |
| `AssinaturaController.listarPlanos()` e `listarPratos(categoria)` como chamadas separadas | No diagrama a lista era a resposta do sistema ao estímulo anterior; na tela são duas chamadas. |
| `CatalogoAssinantes.salvar()` | Persiste as preferências informadas no passo 8. |
| Nova classe `RepositorioAssinaturas` | Persistência em CSV das assinaturas e itens (ativas e encerradas). |
| `informarCodigo` retorna `ResultadoCodigo` (`VALIDO`, `INVALIDO`, `TENTATIVAS_ESGOTADAS`) | Representa as alternativas do FA1 (3 tentativas). |
| `ResumoAssinatura` (record) | Objeto com os dados da confirmação (Tela 11). |
