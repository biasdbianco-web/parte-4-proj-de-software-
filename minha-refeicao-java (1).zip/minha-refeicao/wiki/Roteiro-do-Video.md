# Roteiro do vídeo (≈ 8 a 10 min)

**Objetivo:** explicar o código-fonte a partir dos diagramas UML, mostrando a relação entre eles, e executar o fluxo principal e os fluxos alternativos.

**Antes de gravar:** abra lado a lado (1) a Wiki com o diagrama de sequência e o diagrama de classes, (2) o código no IDE e (3) um terminal na raiz do projeto com `./build.sh` já executado.

## 1. Abertura (30 s)
"Oi, eu sou [nome]. Neste vídeo vou explicar a implementação em Java do cenário *Assinar Plano de Refeições* do Minha Refeição, mostrando como o código segue os diagramas de sequência e de classes de projeto."

## 2. Visão geral da arquitetura (1 min)
- Mostre o **diagrama de classes** e a árvore de pastas em `src/`.
- Fale das três camadas: **fronteira** `TelaAssinatura`, **controle** `AssinaturaController` e **entidades** (`Assinatura`, `Pedido`, `Pagamento`…).
- Cite os catálogos que persistem em CSV e os serviços simulados (SMS, operadora de cartão, gerador de protocolo).

## 3. Do diagrama de sequência ao código (3 min)
Mostre o **diagrama de sequência do fluxo principal** e vá abrindo o código na mesma ordem:
1. **Fronteira → controlador:** em `TelaAssinatura`, mostre `telaInformarCelular()` chamando `controller.informarCelular(...)`. Cada tela do protótipo é um método.
2. **Controlador coordena:** em `AssinaturaController.informarCelular`, mostre `catalogoAssinantes.buscarOuCriar(...)` e `servicoSMS.enviarCodigo(...)` — as mesmas mensagens do diagrama.
3. **Entidades com a regra de negócio:** em `Assinatura.adicionarRefeicoes`, mostre a regra da cota do plano (princípio do especialista na informação) e o `Pedido.adicionarItem`.
4. **Pagamento:** em `informarDadosPagamento`, mostre a sequência `operadora.autorizar` → `pagamento.registrar` → `assinatura.ativar` → `geradorProtocolo.gerar` → `repositorio.salvar`.
5. Mostre a página **Correspondência UML ↔ Código** da Wiki como resumo.

## 4. Relacionamentos do diagrama de classes (1 min)
- **Composição:** `Assinatura` cria seu `Pedido` (`new Pedido()` no campo) e `Pedido` mantém os `ItemPedido`.
- **Agregação:** `Assinatura` recebe o `EnderecoEntrega`; `Cardapio` agrega `Prato`.
- **Classe associativa:** `ItemPedido` liga `Pedido` e `Prato` e guarda a quantidade.
- **Dependências:** controlador recebe catálogos e serviços no construtor (montados em `Main`).

## 5. Demonstração com o sistema funcionando (3 a 4 min)
Execute `./run.sh` (ou `./demo.sh` para as entradas prontas) e mostre:

| Cena | O que fazer | O que mostrar |
|---|---|---|
| **Fluxo principal** | Celular → código do SMS → plano Semanal → preferência vegetariana → 3 pratos → acompanhamento e sobremesa → endereço → cartão `4111111111111111`, `12/28` | Telas 1 a 11, protocolo `#10245` e, em seguida, a opção 2 do menu (assinatura gravada) |
| **FA1** – código inválido | Digite 3 códigos errados | Mensagens de tentativas restantes e envio de novo SMS; depois digite o código certo |
| **FA2** – quantidade excedida | Plano Semanal (5 refeições) e peça 6 pratos principais | Mensagem do limite; ajuste para 3 pratos e siga |
| **FA3** – pagamento recusado | Cartão terminado em `0000` | Mensagem de recusa e status `AGUARDANDO_PAGAMENTO`; escolha 1 e informe cartão válido. Em outra rodada, escolha 2 e mostre a assinatura `ENCERRADA` |

Em cada cena, volte rapidamente ao diagrama de sequência e aponte a mensagem correspondente (por exemplo, no FA2, o `QuantidadeExcedidaException` saindo de `adicionarRefeicoes`).

## 6. Persistência (30 s)
Abra a pasta `data/` e mostre `assinaturas.csv`, `itens_pedido.csv` e `assinantes.csv` com os dados gerados (e o cartão mascarado).

## 7. Fechamento (30 s)
"Resumindo: o diagrama de sequência virou a troca de mensagens entre fronteira, controlador e entidades, o diagrama de classes virou a estrutura de pacotes e relacionamentos, e os fluxos alternativos foram tratados em cada ponto indicado. O código e o README com as instruções de execução estão no GitHub. Obrigado(a)!"

## Dicas
- Grave a tela com a fonte do IDE e do terminal aumentadas.
- Se a entrega exigir a apresentação por mais de uma pessoa, divida as seções de 2 a 5 entre os integrantes; se for individual, deixe claro na abertura.
