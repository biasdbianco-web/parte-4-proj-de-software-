# Diagramas (versão implementada)

Os diagramas da fase de projeto foram mantidos. A implementação apenas acrescentou a **fronteira** (`TelaAssinatura`), que no diagrama anterior estava implícita na comunicação do Assinante com o controlador, e a classe de persistência `RepositorioAssinaturas`. Os ajustes estão listados na página [Correspondência UML ↔ Código](Correspondencia-UML-Codigo).

## 1. Diagrama de sequência — Fluxo principal (com a fronteira)

```mermaid
sequenceDiagram
    actor A as Assinante
    participant T as :TelaAssinatura
    participant C as :AssinaturaController
    participant CA as :CatalogoAssinantes
    participant SMS as :ServicoSMS
    participant CP as :CatalogoPlanos
    participant AS as :Assinatura
    participant AN as :Assinante
    participant CD as :Cardapio
    participant P as :Pedido
    participant PG as :Pagamento
    participant OP as :OperadoraCartaoCredito
    participant GP as :GeradorProtocolo
    participant R as :RepositorioAssinaturas

    Note over A,R: Tela 1 e 2 - identificação (passos 1 a 4)
    A->>T: digita o celular
    T->>C: informarCelular(celular)
    C->>CA: buscarOuCriar(celular)
    C->>SMS: enviarCodigo(celular)
    A->>T: digita o código
    T->>C: informarCodigo(codigo)
    C->>SMS: validarCodigo(celular, codigo)
    SMS-->>C: valido
    C-->>T: VALIDO

    Note over A,R: Tela 3 e 4 - plano e preferências (passos 5 a 9)
    T->>C: listarPlanos()
    C->>CP: listarDisponiveis()
    A->>T: escolhe o plano
    T->>C: selecionarPlano(idPlano)
    C->>CP: buscarPorId(idPlano)
    C->>AS: new Assinatura(assinante, plano)
    AS->>P: new Pedido()
    A->>T: informa preferências
    T->>C: informarPreferencias(preferencias)
    C->>AN: definirPreferencias(preferencias)
    C->>CA: salvar()

    Note over A,R: Tela 5 a 7 - montagem do pedido (passos 10 a 19)
    T->>C: listarPratos(PRINCIPAL)
    C->>CD: listarPratos(categoria, preferencias)
    A->>T: escolhe os pratos
    T->>C: selecionarPratos(ids)
    C->>AS: adicionarRefeicoes(pratos)
    AS->>P: adicionarItem(prato, quantidade)
    T->>C: selecionarAcompanhamentos(ids) / selecionarSobremesas(ids)
    C->>AS: adicionarRefeicoes(pratos)
    T->>C: consultarResumoPedido()
    C->>P: getComposicao()

    Note over A,R: Tela 8 a 11 - entrega, pagamento e confirmação (passos 20 a 32)
    A->>T: informa o endereço
    T->>C: informarEndereco(endereco)
    C->>AS: definirEndereco(endereco)
    C->>AS: alterarStatus(AGUARDANDO_PAGAMENTO)
    C->>AS: calcularValorTotal()
    A->>T: informa o cartão
    T->>C: informarDadosPagamento(cartao)
    C->>PG: new Pagamento(valor, cartao)
    C->>OP: autorizar(cartao, valor)
    OP-->>C: true
    C->>PG: registrar()
    C->>AS: ativar(pagamento)
    C->>GP: gerar()
    C->>AS: definirProtocolo(numero)
    C->>R: salvar(assinatura)
    T->>C: obterResumoConfirmacao()
    C->>AS: getResumoConfirmacao()
    C-->>T: ResumoAssinatura
    T-->>A: Tela 11 - assinatura ativa
```

Os fluxos alternativos (FA1, FA2 e FA3) estão nos diagramas de sequência da atividade anterior. Na implementação, cada um corresponde a:

| Fluxo | Onde está no código |
|---|---|
| FA1 – código inválido | `AssinaturaController.informarCodigo` devolve `INVALIDO` ou `TENTATIVAS_ESGOTADAS` (invalida o código no `ServicoSMS`); `TelaAssinatura.telaConfirmarCodigo` reenvia o SMS |
| FA2 – quantidade excedida | `Assinatura.adicionarRefeicoes` lança `QuantidadeExcedidaException`; `TelaAssinatura.telaPratosPrincipais` informa o limite e pede novo ajuste |
| FA3 – pagamento não autorizado | `informarDadosPagamento` devolve `false`; `TelaAssinatura.telaPagamento` oferece tentar de novo ou `cancelarAssinatura()` (status `ENCERRADA`) |

## 2. Diagrama de classes de projeto (implementado)

```mermaid
classDiagram
    direction TB

    class TelaAssinatura {
        <<fronteira>>
        +iniciar() void
    }

    class AssinaturaController {
        <<controlador>>
        -assinaturaAtual : Assinatura
        +informarCelular(celular) void
        +informarCodigo(codigo) ResultadoCodigo
        +listarPlanos() List~PlanoAssinatura~
        +selecionarPlano(idPlano) PlanoAssinatura
        +informarPreferencias(preferencias) void
        +listarPratos(categoria) List~Prato~
        +selecionarPratos(ids) void
        +selecionarAcompanhamentos(ids) void
        +selecionarSobremesas(ids) void
        +consultarResumoPedido() List~ItemPedido~
        +informarEndereco(endereco) double
        +informarDadosPagamento(cartao) boolean
        +obterResumoConfirmacao() ResumoAssinatura
        +cancelarAssinatura() void
    }

    class CatalogoAssinantes {
        <<collection>>
        +buscarOuCriar(celular) Assinante
        +salvar() void
    }
    class CatalogoPlanos {
        <<collection>>
        +listarDisponiveis() List~PlanoAssinatura~
        +buscarPorId(idPlano) PlanoAssinatura
    }
    class Cardapio {
        <<collection>>
        +listarPratos(categoria, preferencias) List~Prato~
    }
    class RepositorioAssinaturas {
        <<persistencia>>
        +salvar(assinatura) void
        +listarResumos() List~String~
    }
    class ServicoSMS {
        <<servico>>
        +enviarCodigo(celular) void
        +validarCodigo(celular, codigo) boolean
        +invalidarCodigo(celular) void
    }
    class GeradorProtocolo {
        <<servico>>
        +gerar() String
    }
    class OperadoraCartaoCredito {
        <<ator externo>>
        +autorizar(cartao, valor) boolean
    }

    class Assinante {
        -celular : String
        -nome : String
        +definirPreferencias(tipos) void
    }
    class PreferenciaAlimentar {
        -tipo : String
    }
    class PlanoAssinatura {
        -tipo : String
        -quantidadeRefeicoes : int
        -periodicidade : String
        -valor : double
    }
    class Assinatura {
        -status : StatusAssinatura
        -numeroProtocolo : String
        -dataContratacao : Date
        -previsaoPrimeiraEntrega : Date
        +adicionarRefeicoes(pratos) void
        +definirEndereco(endereco) void
        +alterarStatus(status) void
        +calcularValorTotal() double
        +ativar(pagamento) void
        +definirProtocolo(numero) void
        +encerrarSemAtivacao() void
        +getResumoConfirmacao() ResumoAssinatura
    }
    class Pedido {
        -status : String
        -dataCriacao : Date
        +adicionarItem(prato, quantidade) void
        +getComposicao() List~ItemPedido~
        +getQuantidadeTotal() int
        +getQuantidadePorCategoria(categoria) int
        +aprovar() void
    }
    class ItemPedido {
        -quantidade : int
    }
    class Prato {
        -nome : String
        -categoria : CategoriaPrato
        -descricao : String
    }
    class EnderecoEntrega {
        -rua : String
        -numero : String
        -cidade : String
        -cep : String
        -complemento : String
    }
    class Pagamento {
        -valor : double
        -status : String
        -dataPagamento : Date
        +registrar() void
    }
    class CartaoCredito {
        -numero : String
        -validade : String
        -nomeImpresso : String
    }
    class StatusAssinatura {
        <<enumeration>>
        EM_CRIACAO
        AGUARDANDO_PAGAMENTO
        ATIVA
        ENCERRADA
    }
    class CategoriaPrato {
        <<enumeration>>
        PRINCIPAL
        ACOMPANHAMENTO
        SOBREMESA
    }
    class QuantidadeExcedidaException {
        <<exception>>
        -limite : int
    }

    TelaAssinatura --> AssinaturaController : envia estímulos
    AssinaturaController --> CatalogoAssinantes : usa
    AssinaturaController --> CatalogoPlanos : usa
    AssinaturaController --> Cardapio : usa
    AssinaturaController --> ServicoSMS : usa
    AssinaturaController --> GeradorProtocolo : usa
    AssinaturaController --> OperadoraCartaoCredito : solicita autorização
    AssinaturaController --> RepositorioAssinaturas : persiste
    AssinaturaController --> Assinatura : coordena

    CatalogoAssinantes o-- Assinante : guarda
    CatalogoPlanos o-- PlanoAssinatura : guarda
    Cardapio o-- Prato : disponibiliza

    Assinante "1" *-- "0..*" PreferenciaAlimentar : possui
    Assinante "1" --> "0..*" Assinatura : contrata
    Assinatura "0..*" --> "1" PlanoAssinatura : refere-se a
    Assinatura "1" *-- "1" Pedido : gera
    Assinatura "1" o-- "1" EnderecoEntrega : entrega em
    Assinatura "1" *-- "0..1" Pagamento : gera
    Assinatura --> StatusAssinatura
    Pedido "1" *-- "1..*" ItemPedido : contém
    ItemPedido "0..*" --> "1" Prato : refere-se a
    Prato --> CategoriaPrato
    Pagamento "0..*" --> "1" CartaoCredito : realizado com
    Pagamento "0..*" --> "1" OperadoraCartaoCredito : autorizado por
    Assinatura ..> QuantidadeExcedidaException : lança
```
