# Minha Refeição — Implementação do cenário "Assinar Plano de Refeições"

Entrega 4 — Implementação do Cenário do Caso de Uso (Java).

## Conteúdo da Wiki

| Página | O que tem |
|---|---|
| [Diagramas](Diagramas) | Diagrama de sequência (com a fronteira) e diagrama de classes de projeto **como foram implementados** |
| [Correspondência UML ↔ Código](Correspondencia-UML-Codigo) | Para cada mensagem do diagrama de sequência, a classe e o método Java; ajustes feitos na implementação |
| [Roteiro do Vídeo](Roteiro-do-Video) | Roteiro da explicação do código com os diagramas e das demonstrações |
| [Persistência](Persistencia) | Arquivos CSV usados e seus formatos |

## Links da entrega

- **Código-fonte e README (como executar):** [colar aqui o link do repositório]
- **Vídeo de explicação:** [colar aqui o link do vídeo]

## Resumo

O cenário foi implementado em **Java 17** com três camadas: **fronteira** (`TelaAssinatura`, console), **controle** (`AssinaturaController`) e **entidades de domínio** (`Assinatura`, `Pedido`, `Pagamento`…), mais catálogos que persistem em **arquivos CSV** e serviços simulados (SMS, operadora de cartão, gerador de protocolo).
Foram implementados o **fluxo principal** e os fluxos alternativos **FA1** (código inválido), **FA2** (quantidade acima do plano) e **FA3** (pagamento não autorizado).

Autoria: **Beatriz Savazzi Del Bianco**.
