# Persistência (arquivos CSV)

Todos os arquivos ficam na pasta `data/`, em UTF-8, separador `;` e primeira linha com o cabeçalho. A pasta pode ser trocada com `-Ddata.dir=caminho`.

| Arquivo | Colunas | Quem lê/grava |
|---|---|---|
| `planos.csv` | `id;tipo;quantidadeRefeicoes;periodicidade;valor` | lido por `CatalogoPlanos` |
| `pratos.csv` | `id;nome;categoria;descricao;perfis` (perfis separados por `\|`) | lido por `Cardapio` |
| `assinantes.csv` | `id;celular;nome;preferencias` | `CatalogoAssinantes` |
| `assinaturas.csv` | `id;celular;plano;status;protocolo;dataContratacao;previsaoEntrega;endereco;valor;cartao` | `RepositorioAssinaturas` |
| `itens_pedido.csv` | `idAssinatura;idPrato;prato;categoria;quantidade` | `RepositorioAssinaturas` |
| `protocolo.txt` | último número de protocolo gerado | `GeradorProtocolo` |

- Assinaturas **ativas** e **encerradas** (FA3, quando o assinante desiste) são gravadas em `assinaturas.csv`.
- O cartão de crédito é gravado só com o número mascarado (`**** **** **** 1234`).
- Exemplo de conteúdo gerado: veja `demo/saida_exemplo.txt` no repositório.
