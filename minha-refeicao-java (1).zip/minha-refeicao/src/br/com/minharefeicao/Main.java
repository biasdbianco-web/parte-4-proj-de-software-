package br.com.minharefeicao;

import br.com.minharefeicao.catalogo.Cardapio;
import br.com.minharefeicao.catalogo.CatalogoAssinantes;
import br.com.minharefeicao.catalogo.CatalogoPlanos;
import br.com.minharefeicao.catalogo.RepositorioAssinaturas;
import br.com.minharefeicao.controle.AssinaturaController;
import br.com.minharefeicao.fronteira.TelaAssinatura;
import br.com.minharefeicao.servico.GeradorProtocolo;
import br.com.minharefeicao.servico.OperadoraCartaoCredito;
import br.com.minharefeicao.servico.ServicoSMS;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

/** Ponto de entrada: monta os objetos (fronteira, controle, entidades/catálogos, serviços) e inicia a tela. */
public class Main {

    public static void main(String[] args) throws Exception {
        Path dados = Path.of(System.getProperty("data.dir", "data"));
        PrintStream saida = new PrintStream(System.out, true, StandardCharsets.UTF_8);
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

        AssinaturaController controller = new AssinaturaController(
                new CatalogoAssinantes(dados.resolve("assinantes.csv")),
                new CatalogoPlanos(dados.resolve("planos.csv")),
                new Cardapio(dados.resolve("pratos.csv")),
                new ServicoSMS(saida::println),
                new GeradorProtocolo(dados.resolve("protocolo.txt")),
                new OperadoraCartaoCredito(),
                new RepositorioAssinaturas(dados.resolve("assinaturas.csv"), dados.resolve("itens_pedido.csv")));

        new TelaAssinatura(controller, entrada, saida).iniciar();
    }
}
